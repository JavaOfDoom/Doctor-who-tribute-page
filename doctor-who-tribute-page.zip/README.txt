A Pen created at CodePen.io. You can find this one at https://codepen.io/javaofdoom/pen/bOPRWW.

 This is for my first code challenge through freecomecamp.org! It will be a tribute to Doctor Who, one of my very favorite shows!